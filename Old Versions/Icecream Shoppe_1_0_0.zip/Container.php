<?php

/**
 * Representation of Container options
 *
 * @since 1.0.0
 *
 * Created by PhpStorm.
 * @author Tim K.
 * Date: 11/17/2015
 * Time: 11:24 PM
 */
class Container
{
    public static $types = array("Waffle Cone", "Cup", "Cake Cone", "Sugar Cone");
}