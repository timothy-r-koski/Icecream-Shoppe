<?php

/**
 * Representation of Soda options
 *
 * @since 1.0.0
 *
 * Created by PhpStorm.
 * @author Tim K.
 * Date: 11/17/2015
 * Time: 11:07 PM
 */
class Soda
{
    public static $flavours = array("Nuka-Cola", "Quantum", "Sunset Sarsaparilla");
}