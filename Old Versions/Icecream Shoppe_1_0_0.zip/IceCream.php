<?php

/**
 * Representation of IceCream options
 *
 * @since 1.0.0
 *
 * Created by PhpStorm.
 * @author Tim K.
 * Date: 11/17/2015
 * Time: 11:07 PM
 */
class IceCream
{
    public static $flavours = array("Strawberry", "Vanilla", "Chocolate", "Cherry", "Butter Brickle");
}