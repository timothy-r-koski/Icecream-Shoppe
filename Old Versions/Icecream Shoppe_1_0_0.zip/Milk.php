<?php

/**
 * Representation of Milk options
 *
 * @since 1.0.0
 *
 * Created by PhpStorm.
 * @author Tim K.
 * Date: 11/17/2015
 * Time: 11:15 PM
 */
class Milk
{
    public static $types = array("Whole", "2%", "Skim");
}